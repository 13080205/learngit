import java.util.ArrayList;

/**
 * Created by lc on 2016/1/5.
 */
public class main {
    public static void main(String argv[]){
        new rj();
    }
}
